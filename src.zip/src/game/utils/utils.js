export const isZero = (point) => point.x === 0 && point.y === 0;
