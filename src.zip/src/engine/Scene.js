/**
 * @abstract
 */
export class Scene {
	// TBD - Just a placeholder atm :)
}
