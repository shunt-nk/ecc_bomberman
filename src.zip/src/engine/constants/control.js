export const GamepadThumbstick = {
	DEAD_ZONE: 'deadZone',
	HORIZONTAL_AXE_ID: 'horizonalAxeId',
	VERTICAL_AXE_ID: 'verticalAxeId',
};
