import { BombermanGame } from "game/BombermanGame.js";

window.addEventListener("load", () => {
	new BombermanGame().start();
});

